package com.patientinfo.hooman.patientinfo.Data;

public interface ApiService {
}
