package com.patientinfo.hooman.patientinfo.PatinetSendSms;

import android.database.Cursor;

import com.patientinfo.hooman.patientinfo.Classes.G;
import com.patientinfo.hooman.patientinfo.Data.PatientDataSource;
import com.patientinfo.hooman.patientinfo.Data.PatientDatabase;

import java.util.ArrayList;
import java.util.List;

public class SmsSendPresenter implements SendSmsContract.Presenter {
    private SendSmsContract.View view;
    private PatientDatabase patientDatabase;
    private PatientDataSource patientDataSource;
    public SmsSendPresenter(PatientDataSource patientDataSource){
        this.patientDataSource = patientDataSource;
        patientDatabase = new PatientDatabase(G.context);

    }
    @Override
    public void getPatient() {

    }

    @Override
    public void getDisease() {
        Cursor diseaseCursor;
        diseaseCursor = patientDatabase.getDisease();
        view.fillSpinner(diseaseCursor);
    }

    @Override
    public void getCity() {
        Cursor cityCursor;
        cityCursor = patientDatabase.getCity();
        view.fillSpinner(cityCursor);
    }

    @Override
    public void attachView(SendSmsContract.View view) {
        this.view = view;
    }

    @Override
    public void detachView() {
        this.view = null;

    }
}
