package com.patientinfo.hooman.patientinfo.Data;

import android.database.Cursor;

public class ServerDataSource implements PatientDataSource {
    @Override
    public long insertPatient(Patient patient) {
        return 0;
    }

    @Override
    public Cursor searchPatient(CharSequence charSequence) {
        return null;
    }

    @Override
    public Cursor searchPatientByDisease(CharSequence charSequence) {
        return null;
    }

    @Override
    public Cursor searchPatientByIdnumber(CharSequence charSequence) {
        return null;
    }

    @Override
    public Cursor searchPatientByCity(CharSequence charSequence) {
        return null;
    }

    @Override
    public long updatePatientDesc(int id, String desc) {
        return 0;
    }

    @Override
    public long addDrug(String drugName) {
        return 0;
    }

    @Override
    public long addMedicalRecord(int patientId, String visitDate, int soldDrug) {
        return 0;
    }

    @Override
    public Cursor getDrug() {
        return null;
    }

    @Override
    public boolean deletePatient(int id) {
        return false;
    }

    @Override
    public Cursor getPatient(int id) {
        return null;
    }

    @Override
    public long updatePatient(int id, Patient patient) {
        return 0;
    }

    @Override
    public Cursor getDisease() {
        return null;
    }

    @Override
    public Cursor getCity() {
        return null;
    }
}
