package com.patientinfo.hooman.patientinfo.PatinetSendSms;

import android.database.Cursor;

import com.patientinfo.hooman.patientinfo.Base.BasePresenter;
import com.patientinfo.hooman.patientinfo.Base.BaseView;

public interface SendSmsContract {
    interface View extends BaseView{
        void showMessage(String msg);
        void fillSpinner(Cursor spinnerCursor);
    }
    interface Presenter extends BasePresenter<View>{
        void getPatient();
        void getDisease();
        void getCity();
    }
}
