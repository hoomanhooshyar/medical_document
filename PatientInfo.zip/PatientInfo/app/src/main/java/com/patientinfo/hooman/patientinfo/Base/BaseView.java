package com.patientinfo.hooman.patientinfo.Base;

import android.content.Context;

public interface BaseView {
    Context getViewContext();
}
